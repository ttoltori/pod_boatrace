package com.pengkong.boatrace.model.json;

public class Deposit {
	public int receiptNum;
	public String useBankCode;
	public int chargeInstructAmt;
	public int currentBetLimitAmount;
	public int purchasableBetCount;
	public String token;
	public String updateDate;
	public String updateTime;
}
