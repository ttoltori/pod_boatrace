package com.pengkong.boatrace.model.json;

public class Balance {

	public String balrefDate;
	public int initialBetLimitAmount;
	public int todayBetAmount;
	public int todayRefundAmount;
	public int purchasableBetAmount;
	public int transferInstCount;
	public int totalTransferAmount;
	public int transferableAmount;
	public int currentBetLimitAmount;
	public int purchasableBetCount;
	public String nowDate;
	public String nowTime;
	public String token;
}
