package com.pengkong.boatrace.model.json;

public class PayOff {
	public int receiptNum;
	public int accountInstructAmt;
	public String useBankCode;
	public int currentBetLimitAmount;
	public int purchasableBetCount;
	public String token;
	public String updateDate;
	public String updateTime;
}