package com.pengkong.boatrace.model;

import java.math.BigDecimal;

public class ResultInfoSimple {
	public String kumiban;
	public BigDecimal odds;
	public Integer oddsRank;
	public Integer prize;
}
