package com.pengkong.boatrace.model;

public class OddsFItem {
	public String kumiban;
	public Float[] value;

	public OddsFItem(String kumiban, Float[] value) {
		super();
		this.kumiban = kumiban;
		this.value = value;
	}
}
