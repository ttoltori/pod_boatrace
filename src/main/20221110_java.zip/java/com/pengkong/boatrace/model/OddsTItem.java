package com.pengkong.boatrace.model;

public class OddsTItem {
	public String kumiban;
	public float value;
	
	public OddsTItem(String kumiban, float value) {
		super();
		this.kumiban = kumiban;
		this.value = value;
	}
}
