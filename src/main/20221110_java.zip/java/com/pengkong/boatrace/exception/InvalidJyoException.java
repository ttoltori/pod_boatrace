package com.pengkong.boatrace.exception;

public class InvalidJyoException extends Exception {

}
