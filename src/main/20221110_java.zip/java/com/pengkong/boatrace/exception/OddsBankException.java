package com.pengkong.boatrace.exception;

public class OddsBankException extends Exception {

}
