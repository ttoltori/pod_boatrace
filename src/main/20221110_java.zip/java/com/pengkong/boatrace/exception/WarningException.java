package com.pengkong.boatrace.exception;

public class WarningException extends Exception {
	private static final long serialVersionUID = 3506247643525552334L;

	public WarningException(String message) {
		super(message);
	}
}
