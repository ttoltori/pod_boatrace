package com.pengkong.boatrace.exception;

public class UndefinedPatternUnitException extends Exception {
	private static final long serialVersionUID = 1L;

	public UndefinedPatternUnitException(String message) {
		super(message);
	}
	
}
