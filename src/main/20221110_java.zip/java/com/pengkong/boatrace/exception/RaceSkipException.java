package com.pengkong.boatrace.exception;

public class RaceSkipException extends Exception {
	private static final long serialVersionUID = 7629872585412346242L;

	public RaceSkipException(String message) {
		super(message);
	}
}
