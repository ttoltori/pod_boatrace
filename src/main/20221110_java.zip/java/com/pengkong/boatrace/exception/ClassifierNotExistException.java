package com.pengkong.boatrace.exception;

public class ClassifierNotExistException extends Exception {
	private static final long serialVersionUID = 1L;

	public ClassifierNotExistException(String message) {
		super(message);
	}
	
}
