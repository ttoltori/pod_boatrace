package com.pengkong.boatrace.mybatis.entity.ex;

import com.pengkong.boatrace.mybatis.entity.MlResult;

public class MlResultEx extends MlResult {
	/* 使用しない */
	@Deprecated
	public Double probability1;
	@Deprecated
	public Double probability2;
	@Deprecated
	public Double probability3;
	public MlResultEx() {
	}

}
