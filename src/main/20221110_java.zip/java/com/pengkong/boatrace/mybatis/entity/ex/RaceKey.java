package com.pengkong.boatrace.mybatis.entity.ex;

import lombok.Data;

@Data
public class RaceKey {

	private String ymd;
	private String jyocd;
	private Short raceNo;
	
	public RaceKey() {
	}

	
}
