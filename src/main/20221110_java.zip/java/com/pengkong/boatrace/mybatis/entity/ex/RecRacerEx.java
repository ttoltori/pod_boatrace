package com.pengkong.boatrace.mybatis.entity.ex;

import com.pengkong.boatrace.mybatis.entity.RecRacer;

public class RecRacerEx extends RecRacer {
	private String racetype;

	public String getRacetype() {
		return racetype;
	}

	public void setRacetype(String racetype) {
		this.racetype = racetype;
	}
}
