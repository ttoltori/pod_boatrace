package com.pengkong.boatrace.exp10.util;

import java.util.List;

import com.pengkong.boatrace.exp10.simulation.evaluation.Evaluation;

public class DuplicateEvaluationRemover {

	public void execute(String filepath) throws Exception {
		List<Evaluation> listEval = EvaluationHelper.readFile(filepath);
		
	}
	
	public static void main(String[] args) {
		
	}
}
