package com.pengkong.boatrace.exp10.simulation.range;

import java.util.ArrayList;
import java.util.List;

public class BorkRangeStatUnit extends RangeStatUnit {

	public List<Double> listBor = new ArrayList<>();
	public BorkRangeStatUnit(Object factor) {
		super(factor);
	}
}
