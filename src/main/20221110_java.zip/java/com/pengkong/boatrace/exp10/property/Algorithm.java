package com.pengkong.boatrace.exp10.property;

public class Algorithm {
	public String id;
	public String cmd;
	public Algorithm() {
	}
}
