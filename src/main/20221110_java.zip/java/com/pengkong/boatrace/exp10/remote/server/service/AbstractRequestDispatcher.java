package com.pengkong.boatrace.exp10.remote.server.service;

public abstract class AbstractRequestDispatcher {
	public abstract String dispatch(String str);
}
