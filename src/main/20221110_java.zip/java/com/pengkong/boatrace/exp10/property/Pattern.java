package com.pengkong.boatrace.exp10.property;

public class Pattern {
	public String id;
	public String sql;
	public Pattern() {
	}
}
