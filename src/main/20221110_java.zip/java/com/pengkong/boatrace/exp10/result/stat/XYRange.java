package com.pengkong.boatrace.exp10.result.stat;

public class XYRange {
	public Double xMin;
	public Double xMax;
	public Double yMin;
	public Double yMax;
	public XYRange(Double xMin, Double xMax, Double yMin, Double yMax) {
		super();
		this.xMin = xMin;
		this.xMax = xMax;
		this.yMin = yMin;
		this.yMax = yMax;
	}
}
