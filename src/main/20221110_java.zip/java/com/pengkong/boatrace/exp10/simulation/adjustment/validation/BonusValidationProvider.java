package com.pengkong.boatrace.exp10.simulation.adjustment.validation;

import java.util.List;

import com.pengkong.boatrace.exp10.simulation.evaluation.Evaluation;

public class BonusValidationProvider {

	boolean validate(List<Evaluation> listEvaluation) {
		for (Evaluation eval : listEvaluation) {
			
			
		}
		
		
		return false;
	}
}
